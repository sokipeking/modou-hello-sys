// The location of this constant varies.

#include <semaphore.h>
#include <limits.h>

int main(void) { return SEM_VALUE_MAX; }

